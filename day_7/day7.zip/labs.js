// // Select all red shapes in the orange-container
  // $("#orange-container .shape.red");
  // // Select all medium or small shapes inside the green-container
  // $("#green-container .medium, #green-container .small");
  // // Select all shapes inside any container
  // $(".container .shape");
  // // Select all link tags
  // $("li");
  // // Select all link tags inside an "li" tag
  // $("li a");
  // // Count the number of small blue circles
  // $(".small.circle.blue").length;


  // // When 'button 1' is clicked, remove all shapes.
  // $("#button-1").on('click', function(){$(".shape").remove();});
  // // When 'button 2' is clicked, disable button 2 (set the 'disabled' attribute to true)
  // $("#button-2").on('click', function(){$(this).attr("disabled", true);});
  // // When 'button 3' is clicked, set the button message to "Button 3 was clicked"
  // $("#button-3").on('click', function(){$("#button-3").html("Button 3 was clicked");});
  // $("#button-3").on('click', function(){$("#button-message").html("Button 3 was clicked");});

  // // When any shape is clicked, log the value of its "class" attribute to the console
  // $(".shape").on('click', function(){console.log($(this).attr("class"));});
  // // When any shape is clicked, hide it
  // $(".shape").on('click', function(){$(this).hide();});
  // // When any shape is clicked, remove its container
  // $(".shape").on('click', function(){$(this).parent().remove();});
  // // When any container is clicked, remove all the shapes inside
  // $(".container").on('click', function(){$(this).children().remove();});


  // // When your mouse enters any link, log the value of its "href" attribute to the console.
  // // "Your mouse entered a link to: [href]"
  // $("a").on('mouseenter', function(){console.log("Your mouse entered a link to: " + $(this).attr("href"));});
  // // When any button is clicked, set the button message to "Button [button id] was clicked"
  // $(".button").on('click', function(){$(this).html($(this).attr("id") + " was clicked");});

  
